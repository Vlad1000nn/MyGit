#include "MyForm.h"
#include "Header.h"


using namespace System;
using namespace System::Windows::Forms;

//////// Here's programm starting(creating MyForm) \\\\\\\\

[STAThread]
int main(array<String^>^ arg)
{
    setlocale(LC_ALL, "rus");

    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);

    Kursach::MyForm form;
    Application::Run(% form);
    return 0;
}