#pragma once

#include "Header.h"
#include <msclr/marshal_cppstd.h>

namespace Kursach {

	ref class SearchForm;

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;


	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:

		// Constructor
		MyForm(void);

	protected:
		
		// Destructor
		~MyForm();

	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	protected:
	private: System::Windows::Forms::ToolStripMenuItem^ fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ newToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ openToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ saveToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ saveAsToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialog1;
	private: System::Windows::Forms::TextBox^ textBox1;

	private:
		
		// Requied constructor variable
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		
		// Requied method for supporting constructor
		void InitializeComponent(void);

#pragma endregion

		// New
private: System::Void newToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e);

		// Open
private: System::Void openToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e);

	    // ctrl + s
		// ctrl + shift + s
		// ctrl + f
private: System::Void textBox1_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e); 

	    // Save
private: System::Void saveToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e);

	    // Save as
private: System::Void saveAsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e);

	    // Get text from textBox1
public: System::String^ getText();

	    // ���������� ������ � ������� � ���������� 
public: void setCursor(int pos, int length);

	    // Load
private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e);


};
}