#include "SearchForm.h"
#include "MyForm.h"


// Constructor
Kursach::SearchForm::SearchForm(void) {

	InitializeComponent();

	pattern = gcnew System::String(L"");
	text	= gcnew System::String(L"");

	bm		= new BoyerMoore();
	hsh		= new Hash();
	kmp		= new KMP();
	pos		= new INT_VECTOR();
	lengths = new INT_VECTOR();
	t		= new Timerr();
	in_s	= new Innacurate_search();

	currIndex		= 0;
	search_type		= 0;
	case_sensetive	= 1;
	canceled		= 0;
	accurate		= 1;
}


// Destructor
Kursach::SearchForm::~SearchForm() {

	if (components)
	{
		delete components;
	}

	if (bm) delete bm;
	if (hsh) delete hsh;
	if (kmp) delete kmp;
	if (pos) delete pos;
	if (lengths) delete lengths;
	if (t) delete t;
	if (in_s) delete in_s;
}


// Initialize Components
void Kursach::SearchForm::InitializeComponent(void) {
	System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(SearchForm::typeid));
	this->label1 = (gcnew System::Windows::Forms::Label());
	this->label2 = (gcnew System::Windows::Forms::Label());
	this->label3 = (gcnew System::Windows::Forms::Label());
	this->label4 = (gcnew System::Windows::Forms::Label());
	this->label5 = (gcnew System::Windows::Forms::Label());
	this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
	this->textBox1 = (gcnew System::Windows::Forms::TextBox());
	this->button1 = (gcnew System::Windows::Forms::Button());
	this->button2 = (gcnew System::Windows::Forms::Button());
	this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
	this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
	this->checkBox2 = (gcnew System::Windows::Forms::CheckBox());
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->BeginInit();
	this->SuspendLayout();
	// 
	// label1
	// 
	this->label1->AutoSize = true;
	this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->label1->Location = System::Drawing::Point(31, 53);
	this->label1->Name = L"label1";
	this->label1->Size = System::Drawing::Size(65, 25);
	this->label1->TabIndex = 0;
	this->label1->Text = L"What:";
	// 
	// label2
	// 
	this->label2->AutoSize = true;
	this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->label2->Location = System::Drawing::Point(34, 127);
	this->label2->Name = L"label2";
	this->label2->Size = System::Drawing::Size(62, 25);
	this->label2->TabIndex = 1;
	this->label2->Text = L"Time:";
	// 
	// label3
	// 
	this->label3->AutoSize = true;
	this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->label3->Location = System::Drawing::Point(107, 127);
	this->label3->Name = L"label3";
	this->label3->Size = System::Drawing::Size(102, 25);
	this->label3->TabIndex = 2;
	this->label3->Text = L"0 seconds";
	// 
	// label4
	// 
	this->label4->AutoSize = true;
	this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->label4->Location = System::Drawing::Point(298, 101);
	this->label4->Name = L"label4";
	this->label4->Size = System::Drawing::Size(111, 20);
	this->label4->TabIndex = 3;
	this->label4->Text = L"Search Algo";
	// 
	// label5
	// 
	this->label5->AutoSize = true;
	this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->label5->Location = System::Drawing::Point(298, 165);
	this->label5->Name = L"label5";
	this->label5->Size = System::Drawing::Size(117, 20);
	this->label5->TabIndex = 4;
	this->label5->Text = L"Accuracy(%)";
	this->label5->Visible = false;
	// 
	// numericUpDown1
	// 
	this->numericUpDown1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 5, 0, 0, 0 });
	this->numericUpDown1->Location = System::Drawing::Point(302, 188);
	this->numericUpDown1->Name = L"numericUpDown1";
	this->numericUpDown1->Size = System::Drawing::Size(60, 22);
	this->numericUpDown1->TabIndex = 5;
	this->numericUpDown1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 75, 0, 0, 0 });
	this->numericUpDown1->Visible = false;
	// 
	// textBox1
	// 
	this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->textBox1->Location = System::Drawing::Point(112, 48);
	this->textBox1->Name = L"textBox1";
	this->textBox1->Size = System::Drawing::Size(375, 27);
	this->textBox1->TabIndex = 6;
	this->textBox1->TextChanged += gcnew System::EventHandler(this, &SearchForm::textBox1_TextChanged);
	// 
	// button1
	// 
	this->button1->Enabled = false;
	this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->button1->Location = System::Drawing::Point(524, 48);
	this->button1->Name = L"button1";
	this->button1->Size = System::Drawing::Size(133, 30);
	this->button1->TabIndex = 7;
	this->button1->Text = L"Find next";
	this->button1->UseCompatibleTextRendering = true;
	this->button1->UseVisualStyleBackColor = true;
	this->button1->Click += gcnew System::EventHandler(this, &SearchForm::button1_Click);
	// 
	// button2
	// 
	this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->button2->Location = System::Drawing::Point(524, 94);
	this->button2->Name = L"button2";
	this->button2->Size = System::Drawing::Size(133, 34);
	this->button2->TabIndex = 8;
	this->button2->Text = L"Cancel";
	this->button2->UseVisualStyleBackColor = true;
	this->button2->Click += gcnew System::EventHandler(this, &SearchForm::button2_Click);
	// 
	// comboBox1
	// 
	this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->comboBox1->FormattingEnabled = true;
	this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(4) {
		L"Hashing", L"Boyer-Moore", L"Knuth-Morris-Pratt",
			L"Innacurate search"
	});
	this->comboBox1->Location = System::Drawing::Point(302, 128);
	this->comboBox1->Name = L"comboBox1";
	this->comboBox1->Size = System::Drawing::Size(185, 28);
	this->comboBox1->TabIndex = 9;
	this->comboBox1->SelectedIndex = 0; // Default
	this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &SearchForm::comboBox1_SelectedIndexChanged);
	// 
	// checkBox1
	// 
	this->checkBox1->AutoSize = true;
	this->checkBox1->Checked = true;
	this->checkBox1->CheckState = System::Windows::Forms::CheckState::Checked;
	this->checkBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->checkBox1->Location = System::Drawing::Point(524, 141);
	this->checkBox1->Name = L"checkBox1";
	this->checkBox1->Size = System::Drawing::Size(146, 24);
	this->checkBox1->TabIndex = 10;
	this->checkBox1->Text = L"Case sensetive";
	this->checkBox1->UseVisualStyleBackColor = true;
	// 
	// checkBox2
	// 
	this->checkBox2->AutoSize = true;
	this->checkBox2->Checked = true;
	this->checkBox2->CheckState = System::Windows::Forms::CheckState::Checked;
	this->checkBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->checkBox2->Location = System::Drawing::Point(524, 186);
	this->checkBox2->Name = L"checkBox2";
	this->checkBox2->Size = System::Drawing::Size(98, 24);
	this->checkBox2->TabIndex = 11;
	this->checkBox2->Text = L"Accurate";
	this->checkBox2->UseVisualStyleBackColor = true;
	this->checkBox2->CheckedChanged += gcnew System::EventHandler(this, &SearchForm::checkBox2_CheckedChanged);
	// 
	// SearchForm
	// 
	this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
	this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
	this->ClientSize = System::Drawing::Size(692, 222);
	this->Controls->Add(this->checkBox2);
	this->Controls->Add(this->checkBox1);
	this->Controls->Add(this->comboBox1);
	this->Controls->Add(this->button2);
	this->Controls->Add(this->button1);
	this->Controls->Add(this->textBox1);
	this->Controls->Add(this->numericUpDown1);
	this->Controls->Add(this->label5);
	this->Controls->Add(this->label4);
	this->Controls->Add(this->label3);
	this->Controls->Add(this->label2);
	this->Controls->Add(this->label1);
	this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
	this->MaximizeBox = false;
	this->MinimizeBox = false;
	this->Name = L"SearchForm";
	this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
	this->Text = L"Search";
	this->TopMost = true;
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->EndInit();
	this->ResumeLayout(false);
	this->PerformLayout();

}


// TextBox1 Text Changed
System::Void Kursach::SearchForm::textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {

	if (String::IsNullOrEmpty(textBox1->Text))
		button1->Enabled = false;
	else
		button1->Enabled = true;
}

// CheckBox2 Check Changed
System::Void Kursach::SearchForm::checkBox2_CheckedChanged(System::Object^ sender, System::EventArgs^ e)
{
	if (checkBox2->Checked)
		hsh->accurate();
	else hsh->quick();
}

// Find button click
System::Void Kursach::SearchForm::button1_Click(System::Object^ sender, System::EventArgs^ e) {

	// Reading pattern
	System::String^ patternString = textBox1->Text;
	std::wstring newPattern = msclr::interop::marshal_as<std::wstring>(patternString);

	// Recording current pattern
	System::String^ buffPattern = pattern;
	std::wstring currPattern = msclr::interop::marshal_as<std::wstring>(buffPattern);

	// Reading Text
	System::String^ textString = form1->getText();
	std::wstring newText = msclr::interop::marshal_as<std::wstring>(textString);

	// Recording current text
	System::String^ buffText = text;
	std::wstring currText = msclr::interop::marshal_as<std::wstring>(buffText);

	bool text_changed{}, pattern_changed{}, type_changed{}, case_changed{}, is_cancel{};

	// If last-search case-sensetive not equal to new
	if (case_sensetive != checkBox1->Checked)
	{
		case_changed = 1;
		// Update
		case_sensetive = checkBox1->Checked;
	}

	// If last-search search-type not equal to the new
	if (search_type != comboBox1->SelectedIndex)
	{
		type_changed = 1;
		// Update
		search_type = comboBox1->SelectedIndex;
	}

	// If last-search pattern
	if (newPattern != currPattern)
	{
		pattern_changed = 1;
		// Update
		pattern = patternString;
	}

	// If last-search text not equal to the new
	if (currText != newText)
	{
		text_changed = 1;
		// Update
		text = textString;
	}

	// If we don't have case_sensetive making currText and 
	if (!case_sensetive)
	{
		for (auto& it : newPattern)
			it = towlower(it);

		for (auto& it : newText)
			it = towlower(it);
	}

	
	make_answer(text_changed, pattern_changed, type_changed, case_changed, newPattern, newText);
	
	// Now we cancel button2
	canceled = 0;
}


// Cancel button click
System::Void Kursach::SearchForm::button2_Click(System::Object^ sender, System::EventArgs^ e) {

	label3->Text = "0 seconds";
	textBox1->Text = "";
	form1->setCursor(0, 0);
	checkBox1->Checked = 1;
	comboBox1->SelectedIndex = 0;
	numericUpDown1->Value = 75;
	canceled = 1;
}


// CombobBox1 Selected Index Changed
System::Void Kursach::SearchForm::comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {

	if (comboBox1->SelectedIndex == 3)
	{
		label5->Visible = true;
		numericUpDown1->Visible = true;
	}
	else
	{
		label5->Visible = false;
		numericUpDown1->Visible = false;
	}

	if (comboBox1->SelectedIndex == 0)
		checkBox2->Visible = true;
	else
		checkBox2->Visible = false;
}


// Calculate answer
void Kursach::SearchForm::make_answer(bool text_changed, bool pattern_changed, bool type_changed,
									  bool case_changed, const std::wstring& newPattern, const std::wstring& newText) {

	if ((int)newText.length() < (int)newPattern.length())
	{
		System::Windows::Forms::MessageBox::Show("������� ������ �� ����� ���� ������ ������!", "���������", System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information);
		return;
	}

	bool something_changed = pattern_changed || type_changed || text_changed || canceled || case_changed;

	if (something_changed || in_s->get_accuracy() != (double)numericUpDown1->Value || (hsh->state() - 1 != accurate && !search_type))
		t->reset();

	switch (search_type)
	{
	case 0:
	{
		if (something_changed || hsh->state() - 1 != accurate)
		{
			pos->rebuild(hsh->find(newPattern,newText));
		}

		break;
	}
	case 1:
	{
		if (something_changed)
		{
			bm->rebuild(newPattern);
			pos->rebuild(bm->find(newText));
		}

		break;
	}
	case 2:
	{
		if (something_changed)
		{
			kmp->rebuild(newText);
			pos->rebuild(kmp->find(newPattern));
		}

		break;
	}
	case 3:
	{
		if (something_changed || in_s->get_accuracy() != (double)numericUpDown1->Value)
		{
			in_s->text_rebuild(newText);
			in_s->pattern_rebuild(newPattern);
			in_s->accuracy((double)numericUpDown1->Value);

			std::vector<std::pair<int, int>> vec = in_s->find();
			const int cnt = (int)vec.size();

			std::vector<int> lens(cnt);
			std::vector<int> poses(cnt);

			for (int i = 0; i < cnt; ++i)
			{
				poses[i] = vec[i].first;
				lens[i] = vec[i].second;
			}

			pos->rebuild(poses);
			lengths->rebuild(lens);

			currIndex = 0;

			std::ostringstream oss;
			oss << std::fixed << t->elapsed();
			std::string str = oss.str();

			System::String^ formattedString = gcnew System::String(str.c_str());
			formattedString += " seconds";
			label3->Text = formattedString;
		}

		move_cursor(lengths);

		return;
	}
	default:
	{
		t->reset();
		pos->rebuild(naive->find(newPattern, newText));
		// print message
		//System::Windows::Forms::MessageBox::Show("��������� ������. ��������� ������������ ���������� ���������!", "���������", System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information);
	}

	}

	if (something_changed || (hsh->state() - 1 != accurate && !search_type))
	{
		currIndex = 0;
		if (!search_type)
			accurate = checkBox2->Checked;

		std::ostringstream oss;
		oss << std::fixed << t->elapsed();
		std::string str = oss.str();

		System::String^ formattedString = gcnew System::String(str.c_str());
		formattedString += " seconds";
		label3->Text = formattedString;
	}

	move_cursor((int)newPattern.length());
}


// For 0,1,2 Algos
void Kursach::SearchForm::move_cursor(int m) {

	// If pos-vector is empty
	if (!pos->size())
	{
		// Print message, that there're no matches
		System::Windows::Forms::MessageBox::Show("���������� �� �������.", "���������", System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information);
	}
	// If it's not empty
	else
	{
		int currPos = pos->at(currIndex);
		// �������� �������� ���� � pos[currIndex] �� pos[currIndex] + pattern.size()
		form1->setCursor(currPos, m);

		++currIndex;
		// ���� ����� �� �����, �� �������� � ������ �������
		if (pos->size() == currIndex)
			currIndex = 0;
	}
}


// For 3 Algo
void Kursach::SearchForm::move_cursor(INT_VECTOR* vec) {

	// If pos-vector is empty
	if (!pos->size())
	{
		// Print message, that there're no matches
		System::Windows::Forms::MessageBox::Show("���������� �� �������.", "���������", System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information);
	}
	// If it's not empty
	else
	{
		int currLength = lengths->at(currIndex);
		int currPos = pos->at(currIndex);
		// �������� �������� ���� � pos[currIndex] �� pos[currIndex] + pattern.size()
		form1->setCursor(currPos, currLength);

		++currIndex;
		// ���� ����� �� �����, �� �������� � ������ �������
		if (pos->size() == currIndex)
			currIndex = 0;
	}
}


// Set form1
void Kursach::SearchForm::setForm1(MyForm^ form) {
	this->form1 = form;
}