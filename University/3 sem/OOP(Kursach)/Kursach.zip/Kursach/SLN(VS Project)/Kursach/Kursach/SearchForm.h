#pragma once

#include "Searching.h"

namespace Kursach {

	ref class MyForm;

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	public ref class SearchForm : public System::Windows::Forms::Form
	{
	public:

		// Constructor
		SearchForm(void);

	protected:
		
		// Destructor
		~SearchForm();


	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::CheckBox^ checkBox1;

	private: BoyerMoore* bm;							// BM search
	private: Hash* hsh;									// Hash search
	private: KMP* kmp;									// KMP search
	private: Innacurate_search* in_s;					// Innacurate search
	private: Naive* naive;								// Naive search

	private: MyForm^ form1;								// ref to MyForm

	private: System::String^ text;						// Text from MyForm
	private: System::String^ pattern;					// Pattern from SearchForm

	private: INT_VECTOR* pos;							// Positions of pattern in text
	private: INT_VECTOR* lengths;						// Lengths of similar pattern substrings(Innacurate_search)

	private: int currIndex;								// Curr Index in pos
	private: int search_type;							// Search type

	private: Timerr* t;									// Calculate time to search

	private: bool case_sensetive;						// Do we need make case sensetive?
	private: bool accurate;								// Quick / accurate
	private: bool canceled;								// Did we cancel search or not?
	private: System::Windows::Forms::CheckBox^ checkBox2;



	private:

		// Required constructor variable
		System::ComponentModel::Container ^components;


#pragma region Windows Form Designer generated code

		// Required method to support the constructor 
		void InitializeComponent(void);

#pragma endregion

		// textBox1 Text Changed
private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e);

		// Checkbox2 checkChanged
	private: System::Void checkBox2_CheckedChanged(System::Object^ sender, System::EventArgs^ e);

	    // Find Button click
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e);

	    // Calculate answer
private: void make_answer(bool text_changed, bool pattern_changed, bool type_changed,
						  bool case_changed, const std::wstring& newPattern, const std::wstring& newText);

	    // ComboBox1 Selected Index Changed
private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e);

		// For 0,1,2 Algos
private: void move_cursor(int m);

		// For 3 Algo
private: void move_cursor(INT_VECTOR* vec);
	
	    // Cancel button click
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e);

	    // Set form1
public: void setForm1(MyForm^ form); 


	};

}
