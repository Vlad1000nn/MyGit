#include "MyForm.h"
#include "SearchForm.h"


// Constructor
Kursach::MyForm::MyForm(void) {

	InitializeComponent();

	std::ifstream file("buffer.txt");
	if (!file) {
		std::ofstream newFile("buffer.txt");
		newFile.close();
	}
}


// Destructor
Kursach::MyForm::~MyForm() {

	if (components)
	{
		delete components;
	}
}


// Initialize Components
void Kursach::MyForm::InitializeComponent(void) {
	System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
	this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
	this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
	this->newToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
	this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
	this->saveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
	this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
	this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
	this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
	this->textBox1 = (gcnew System::Windows::Forms::TextBox());
	this->menuStrip1->SuspendLayout();
	this->SuspendLayout();
	this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
	this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->fileToolStripMenuItem });
	this->menuStrip1->Location = System::Drawing::Point(0, 0);
	this->menuStrip1->Name = L"menuStrip1";
	this->menuStrip1->Size = System::Drawing::Size(1169, 30);
	this->menuStrip1->TabIndex = 0;
	this->menuStrip1->Text = L"menuStrip1";
	this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {
		this->newToolStripMenuItem,
			this->openToolStripMenuItem, this->saveToolStripMenuItem, this->saveAsToolStripMenuItem
	});
	this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
	this->fileToolStripMenuItem->Size = System::Drawing::Size(46, 26);
	this->fileToolStripMenuItem->Text = L"File";
	this->newToolStripMenuItem->Name = L"newToolStripMenuItem";
	this->newToolStripMenuItem->Size = System::Drawing::Size(265, 26);
	this->newToolStripMenuItem->Text = L"New";
	this->newToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::newToolStripMenuItem_Click);
	this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
	this->openToolStripMenuItem->Size = System::Drawing::Size(265, 26);
	this->openToolStripMenuItem->Text = L"Open";
	this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::openToolStripMenuItem_Click);
	this->saveToolStripMenuItem->Name = L"saveToolStripMenuItem";
	this->saveToolStripMenuItem->ShortcutKeyDisplayString = L"CTRL + S";
	this->saveToolStripMenuItem->Size = System::Drawing::Size(265, 26);
	this->saveToolStripMenuItem->Text = L"Save";
	this->saveToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::saveToolStripMenuItem_Click);
	this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
	this->saveAsToolStripMenuItem->ShortcutKeyDisplayString = L"CTRL + SHIFT + S";
	this->saveAsToolStripMenuItem->Size = System::Drawing::Size(265, 26);
	this->saveAsToolStripMenuItem->Text = L"Save as";
	this->saveAsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::saveAsToolStripMenuItem_Click);
	this->openFileDialog1->FileName = L"openFileDialog1";
	this->textBox1->BackColor = System::Drawing::SystemColors::ScrollBar;
	this->textBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
	this->textBox1->Dock = System::Windows::Forms::DockStyle::Fill;
	this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
		static_cast<System::Byte>(204)));
	this->textBox1->HideSelection = false;
	this->textBox1->Location = System::Drawing::Point(0, 30);
	this->textBox1->Margin = System::Windows::Forms::Padding(4);
	this->textBox1->Multiline = true;
	this->textBox1->Name = L"textBox1";
	this->textBox1->ScrollBars = System::Windows::Forms::ScrollBars::Both;
	this->textBox1->Size = System::Drawing::Size(1169, 572);
	this->textBox1->TabIndex = 1;
	this->textBox1->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &MyForm::textBox1_KeyDown);
	this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
	this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
	this->ClientSize = System::Drawing::Size(1169, 602);
	this->Controls->Add(this->textBox1);
	this->Controls->Add(this->menuStrip1);
	this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
	this->MainMenuStrip = this->menuStrip1;
	this->Name = L"MyForm";
	this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
	this->Text = L"MyTextEditor";
	this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
	this->menuStrip1->ResumeLayout(false);
	this->menuStrip1->PerformLayout();
	this->ResumeLayout(false);
	this->PerformLayout();

}


// New
System::Void Kursach::MyForm::newToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	textBox1->Text = "";
}


// Open
System::Void Kursach::MyForm::openToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
	{
		StreamReader^ sr = gcnew StreamReader(openFileDialog1->FileName);
		textBox1->Text = sr->ReadToEnd();
		sr->Close();
	}
}


// Save
System::Void Kursach::MyForm::saveToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	System::String^ textFromTextBox = textBox1->Text;

	std::string text = msclr::interop::marshal_as<std::string>(textFromTextBox);

	std::ofstream file("buffer.txt");

	if (file)
	{
		file << text;
		file.close();
	}
	else
		MessageBox::Show("�� ������� ������� ���� buffer.txt", "������", MessageBoxButtons::OK, MessageBoxIcon::Error);
}


// Save as
System::Void Kursach::MyForm::saveAsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
	{
		StreamWriter^ sw = gcnew StreamWriter(saveFileDialog1->FileName);
		sw->Write(textBox1->Text);
		sw->Close();
	}
}


// Load
System::Void Kursach::MyForm::MyForm_Load(System::Object^ sender, System::EventArgs^ e) {

	std::ifstream file("buffer.txt");
	if (file)
	{
		std::string fileContents((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());


		System::String^ text = gcnew System::String(fileContents.c_str());
		textBox1->Text = text;

		file.close();
	}
	else
		textBox1->Text = "";
}


// ctrl + s
// ctrl + shift + s
// ctrl + f
System::Void Kursach::MyForm::textBox1_KeyDown(System::Object^ sender, System::Windows::Forms::KeyEventArgs^ e) {
	if (e->Control)
	{
		if (e->Shift && e->KeyCode == Keys::S)
		{
			saveAsToolStripMenuItem_Click(sender, e);
			e->SuppressKeyPress = true;
		}
		else if (e->KeyCode == Keys::S)
		{
			saveToolStripMenuItem_Click(sender, e);
			e->SuppressKeyPress = true;
		}
		else if (e->KeyCode == Keys::F)
		{
			SearchForm^ searchForm = gcnew SearchForm();
			searchForm->setForm1(this);

			searchForm->Show();

			e->SuppressKeyPress = true;
		}
	}
}


// Get text from TextBox1
System::String^ Kursach::MyForm::getText() {

	return textBox1->Text;
}


// Set the cursor to the marked position
void Kursach::MyForm::setCursor(int pos, int length) {

	textBox1->SelectionStart = pos;
	textBox1->SelectionLength = length;
}