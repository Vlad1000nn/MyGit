#pragma once

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <random>
#include <locale.h>
#include <locale>
#include <fstream>
#include <sstream>
#include <chrono>
#include <numeric>